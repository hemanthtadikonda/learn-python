#!/usr/bin/env python3
"""
TODO: Implement script #36: Cli Argparse Template.Py
Refer to roadmap for requirements.
"""
def main():
    print("This is a placeholder for script #36.")

if __name__ == "__main__":
    main()
