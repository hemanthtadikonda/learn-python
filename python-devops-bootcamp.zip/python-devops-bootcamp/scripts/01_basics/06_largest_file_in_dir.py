
#!/usr/bin/env python3
"""
Find the largest file in a directory.
Use case: debugging disk usage.
"""
import argparse, pathlib, sys

def main():
    p = argparse.ArgumentParser()
    p.add_argument("directory", type=pathlib.Path)
    a = p.parse_args()
    if not a.directory.is_dir():
        print(f"Not a directory: {a.directory}", file=sys.stderr); sys.exit(2)
    largest = None
    for path in a.directory.rglob("*"):
        if path.is_file():
            size = path.stat().st_size
            if largest is None or size > largest[1]:
                largest = (path, size)
    if largest:
        print(f"{largest[0]}\t{largest[1]} bytes")
    else:
        print("No files found.")

if __name__ == "__main__":
    main()
