
#!/usr/bin/env python3
"""
Even/Odd checker.
Use case: demo input validation logic used in config validators.
"""
import argparse

def is_even(n: int) -> bool:
    return n % 2 == 0

def main():
    parser = argparse.ArgumentParser(description="Check if a number is even or odd")
    parser.add_argument("number", type=int, help="Integer to check")
    args = parser.parse_args()
    print("even" if is_even(args.number) else "odd")

if __name__ == "__main__":
    main()
