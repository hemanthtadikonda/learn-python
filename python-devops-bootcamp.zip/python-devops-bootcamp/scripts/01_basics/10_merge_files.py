
#!/usr/bin/env python3
"""
Merge multiple files into one.
Use case: combine logs from multiple nodes.
"""
import argparse, pathlib, sys

def main():
    p = argparse.ArgumentParser()
    p.add_argument("output", type=pathlib.Path)
    p.add_argument("inputs", nargs="+", type=pathlib.Path)
    a = p.parse_args()
    with a.output.open("w", encoding="utf-8") as out:
        for inp in a.inputs:
            if not inp.exists():
                print(f"Skipping missing: {inp}", file=sys.stderr); continue
            out.write(inp.read_text(encoding="utf-8", errors="replace"))
    print(f"Merged into {a.output}")

if __name__ == "__main__":
    main()
