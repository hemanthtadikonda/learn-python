
#!/usr/bin/env python3
"""
Count occurrences of a word (e.g., ERROR) in a file.
Use case: quick incident triage.
"""
import argparse, pathlib, sys

def main():
    p = argparse.ArgumentParser()
    p.add_argument("path", type=pathlib.Path)
    p.add_argument("--word", default="ERROR")
    a = p.parse_args()
    if not a.path.exists():
        print(f"File not found: {a.path}", file=sys.stderr); sys.exit(2)
    count = 0
    with a.path.open("r", encoding="utf-8", errors="replace") as f:
        for line in f:
            count += line.count(a.word)
    print(count)

if __name__ == "__main__":
    main()
