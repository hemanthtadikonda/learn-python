
#!/usr/bin/env python3
"""
Factorial using recursion.
Use case: learn recursion patterns (useful when walking trees of files/configs).
"""
import argparse

def fact(n: int) -> int:
    if n < 0:
        raise ValueError("n must be >= 0")
    return 1 if n in (0,1) else n * fact(n-1)

def main():
    p = argparse.ArgumentParser()
    p.add_argument("n", type=int)
    a = p.parse_args()
    print(fact(a.n))

if __name__ == "__main__":
    main()
