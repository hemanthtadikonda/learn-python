
#!/usr/bin/env python3
"""
Read a file and print lines with numbers.
Use case: log parsing primitives.
"""
import argparse, sys, pathlib

def main():
    p = argparse.ArgumentParser()
    p.add_argument("path", type=pathlib.Path)
    a = p.parse_args()
    if not a.path.exists():
        print(f"File not found: {a.path}", file=sys.stderr); sys.exit(2)
    with a.path.open("r", encoding="utf-8", errors="replace") as f:
        for i, line in enumerate(f, 1):
            print(f"{i:5d}: {line.rstrip()}"))

if __name__ == "__main__":
    main()
