
#!/usr/bin/env python3
"""
Create a timestamped backup of a file.
Use case: protect configs before patching.
"""
import argparse, pathlib, shutil
from datetime import datetime

def main():
    p = argparse.ArgumentParser()
    p.add_argument("path", type=pathlib.Path)
    a = p.parse_args()
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = a.path.with_suffix(a.path.suffix + f".bak-{stamp}")
    shutil.copy2(a.path, backup)
    print(f"Backup created: {backup}")

if __name__ == "__main__":
    main()
