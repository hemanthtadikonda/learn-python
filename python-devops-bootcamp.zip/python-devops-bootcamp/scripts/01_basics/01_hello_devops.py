
#!/usr/bin/env python3
"""
Prints a friendly message with current date/time.
Use case: sanity test for Python runtime in CI agents or servers.
"""
from datetime import datetime

def main():
    print(f"Hello, DevOps Engineer! It's {datetime.now().isoformat(timespec='seconds')}")

if __name__ == "__main__":
    main()
