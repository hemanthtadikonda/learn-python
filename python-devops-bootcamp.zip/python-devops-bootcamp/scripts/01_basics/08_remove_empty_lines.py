
#!/usr/bin/env python3
"""
Remove empty lines from a file (in-place, creates .bak).
Use case: clean configs/logs before processing.
"""
import argparse, pathlib, shutil

def main():
    p = argparse.ArgumentParser()
    p.add_argument("path", type=pathlib.Path)
    a = p.parse_args()
    bak = a.path.with_suffix(a.path.suffix + ".bak")
    shutil.copy2(a.path, bak)
    lines = [l for l in a.path.read_text(encoding="utf-8", errors="replace").splitlines() if l.strip()]
    a.path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Cleaned {a.path} (backup at {bak})")

if __name__ == "__main__":
    main()
