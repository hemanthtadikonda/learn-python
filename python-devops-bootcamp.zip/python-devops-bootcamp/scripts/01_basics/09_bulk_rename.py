
#!/usr/bin/env python3
"""
Bulk rename files using a prefix pattern.
Use case: normalize build artifact names.
"""
import argparse, pathlib

def main():
    p = argparse.ArgumentParser()
    p.add_argument("directory", type=pathlib.Path)
    p.add_argument("--prefix", default="file_")
    a = p.parse_args()
    i = 1
    for path in sorted(a.directory.glob("*")):
        if path.is_file():
            new = path.with_name(f"{a.prefix}{i}{path.suffix}")
            path.rename(new)
            print(f"{path.name} -> {new.name}")
            i += 1

if __name__ == "__main__":
    main()
