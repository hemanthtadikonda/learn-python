
#!/usr/bin/env python3
"""
Convert JSON to YAML.
Use case: convert Terraform outputs for Ansible/K8s consumption.
"""
import argparse, json, pathlib, sys, yaml

def main():
    p = argparse.ArgumentParser()
    p.add_argument("src", type=pathlib.Path)
    p.add_argument("dst", type=pathlib.Path)
    a = p.parse_args()
    try:
        data = json.loads(a.src.read_text(encoding="utf-8"))
        a.dst.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")
        print(f"Wrote YAML -> {a.dst}")
    except Exception as e:
        print(f"error: {e}", file=sys.stderr); sys.exit(1)

if __name__ == "__main__":
    main()
