
#!/usr/bin/env python3
"""
Parse a JSON config and print top-level keys.
Use case: validate infra config files.
"""
import argparse, json, pathlib, sys

def main():
    p = argparse.ArgumentParser()
    p.add_argument("path", type=pathlib.Path)
    a = p.parse_args()
    try:
        data = json.loads(a.path.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"read/parse error: {e}", file=sys.stderr); sys.exit(2)
    for k in sorted(data.keys()):
        print(k)

if __name__ == "__main__":
    main()
