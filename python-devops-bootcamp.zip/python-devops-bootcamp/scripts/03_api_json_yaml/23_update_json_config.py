
#!/usr/bin/env python3
"""
Update a key in a JSON config in-place (creates .bak).
Use case: dynamic config updates in pipelines.
"""
import argparse, json, pathlib, shutil, sys

def main():
    p = argparse.ArgumentParser()
    p.add_argument("path", type=pathlib.Path)
    p.add_argument("--key", required=True)
    p.add_argument("--value", required=True, help="new value (JSON decoded if possible)")
    a = p.parse_args()
    bak = a.path.with_suffix(a.path.suffix + ".bak")
    try:
        data = json.loads(a.path.read_text(encoding="utf-8"))
        try:
            new_val = json.loads(a.value)
        except Exception:
            new_val = a.value
        old = data.get(a.key, None)
        data[a.key] = new_val
        shutil.copy2(a.path, bak)
        a.path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        print(f"Updated {a.key}: {old} -> {new_val}")
    except Exception as e:
        print(f"error: {e}", file=sys.stderr); sys.exit(1)

if __name__ == "__main__":
    main()
