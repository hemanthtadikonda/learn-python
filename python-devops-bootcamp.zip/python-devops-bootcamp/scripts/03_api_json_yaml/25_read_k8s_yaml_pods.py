
#!/usr/bin/env python3
"""
Read a Kubernetes YAML file (manifests) and print Pod/Deployment/StatefulSet names.
Use case: fast validation of manifests in CI.
"""
import argparse, sys, pathlib, yaml

KINDS = {"Pod","Deployment","StatefulSet","DaemonSet","Job","CronJob"}

def main():
    p = argparse.ArgumentParser()
    p.add_argument("path", type=pathlib.Path)
    a = p.parse_args()
    try:
        docs = list(yaml.safe_load_all(a.path.read_text(encoding='utf-8')))
    except Exception as e:
        print(f"read/parse error: {e}", file=sys.stderr); sys.exit(2)
    for d in docs:
        if not isinstance(d, dict): 
            continue
        kind = d.get("kind")
        if kind in KINDS:
            name = d.get("metadata",{}).get("name","<noname>")
            print(f"{kind}: {name}")

if __name__ == "__main__":
    main()
