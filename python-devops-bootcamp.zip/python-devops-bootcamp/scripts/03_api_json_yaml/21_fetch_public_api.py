
#!/usr/bin/env python3
"""
Fetch a sample public API (Open-Meteo) for current weather by city (via a tiny city->coords mapping).
Use case: practice requests + error handling.
"""
import argparse, requests, sys

CITIES = {
    "Hyderabad": (17.3850, 78.4867),
    "Bengaluru": (12.9716, 77.5946),
    "Mumbai": (19.0760, 72.8777),
    "Delhi": (28.6139, 77.2090),
}

def fetch_weather(lat, lon):
    url = "https://api.open-meteo.com/v1/forecast"
    params = {"latitude": lat, "longitude": lon, "current_weather": True}
    r = requests.get(url, params=params, timeout=10)
    r.raise_for_status()
    return r.json().get("current_weather", {})

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--city", default="Hyderabad", choices=list(CITIES.keys()))
    a = p.parse_args()
    latlon = CITIES[a.city]
    try:
        data = fetch_weather(*latlon)
        print(data)
    except requests.RequestException as e:
        print(f"API error: {e}", file=sys.stderr); sys.exit(1)

if __name__ == "__main__":
    main()
