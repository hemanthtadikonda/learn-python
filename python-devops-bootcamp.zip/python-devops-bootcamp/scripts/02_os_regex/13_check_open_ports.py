
#!/usr/bin/env python3
"""
Check if TCP ports are open on a host.
Use case: validate app/listener bindings in releases.
"""
import argparse, socket

def is_open(host, port, timeout=1.0):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(timeout)
        return s.connect_ex((host, port)) == 0

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--ports", nargs="+", type=int, required=True)
    a = p.parse_args()
    for port in a.ports:
        print(f"{a.host}:{port} -> {'OPEN' if is_open(a.host, port) else 'CLOSED'}")

if __name__ == "__main__":
    main()
