
#!/usr/bin/env python3
"""
Print system uptime (seconds).
Use case: SLA/availability checks.
"""
import time, psutil
boot = psutil.boot_time()
print(int(time.time() - boot))
