
#!/usr/bin/env python3
"""
Extract IPv4 addresses from a file.
Use case: track client IPs from access logs.
"""
import argparse, re, pathlib, sys

IPV4 = re.compile(r"\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b")

def main():
    p = argparse.ArgumentParser()
    p.add_argument("path", type=pathlib.Path)
    a = p.parse_args()
    if not a.path.exists():
        print("file not found", file=sys.stderr); sys.exit(2)
    with a.path.open("r", encoding="utf-8", errors="replace") as f:
        for line in f:
            for m in IPV4.findall(line):
                print(m)

if __name__ == "__main__":
    main()
