
#!/usr/bin/env python3
"""
Check if a service is running (systemd via psutil name contains).
Use case: quick service health check for nginx/sshd/etc.
"""
import argparse, psutil, sys

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--name", required=True, help="substring of process name, e.g., nginx or sshd")
    a = p.parse_args()
    found = False
    for proc in psutil.process_iter(['name']):
        if a.name.lower() in (proc.info.get('name') or '').lower():
            found = True; break
    print("RUNNING" if found else "NOT RUNNING")
    sys.exit(0 if found else 1)

if __name__ == "__main__":
    main()
