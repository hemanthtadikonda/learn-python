
#!/usr/bin/env python3
"""
Ping a list of hosts (uses system ping).
Use case: quick infra reachability checks.
"""
import argparse, subprocess, sys, platform

def ping(host, count=1, timeout=2):
    cmd = ["ping", "-c" if platform.system() != "Windows" else "-n", str(count), host]
    try:
        out = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout, text=True)
        return out.returncode == 0, out.stdout
    except Exception as e:
        return False, str(e)

def main():
    p = argparse.ArgumentParser()
    p.add_argument("hosts", nargs="+")
    a = p.parse_args()
    for h in a.hosts:
        ok, _ = ping(h)
        print(f"{h}: {'UP' if ok else 'DOWN'}")

if __name__ == "__main__":
    main()
