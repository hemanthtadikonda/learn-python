
#!/usr/bin/env python3
"""
Extract emails matching a domain from a file.
Use case: security/account audits.
"""
import argparse, re, pathlib, sys

def main():
    p = argparse.ArgumentParser()
    p.add_argument("path", type=pathlib.Path)
    p.add_argument("--domain", default="example.com")
    a = p.parse_args()
    if not a.path.exists():
        print("file not found", file=sys.stderr); sys.exit(2)
    pat = re.compile(rf"[\w.\-+]+@{re.escape(a.domain)}")
    with a.path.open("r", encoding="utf-8", errors="replace") as f:
        for line in f:
            for m in pat.findall(line):
                print(m)

if __name__ == "__main__":
    main()
