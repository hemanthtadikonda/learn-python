
#!/usr/bin/env python3
"""
Extract a key's value from a .env-like file.
Use case: validate required config presence in CI/CD.
"""
import argparse, re, pathlib, sys

def main():
    p = argparse.ArgumentParser()
    p.add_argument("path", type=pathlib.Path)
    p.add_argument("key", help="ENV KEY like DB_HOST")
    a = p.parse_args()
    if not a.path.exists():
        print("file not found", file=sys.stderr); sys.exit(2)
    pat = re.compile(rf"^{re.escape(a.key)}\s*=\s*(.*)$")
    with a.path.open("r", encoding="utf-8", errors="replace") as f:
        for line in f:
            m = pat.search(line)
            if m:
                print(m.group(1).strip()); return
    print("NOT FOUND", file=sys.stderr); sys.exit(1)

if __name__ == "__main__":
    main()
