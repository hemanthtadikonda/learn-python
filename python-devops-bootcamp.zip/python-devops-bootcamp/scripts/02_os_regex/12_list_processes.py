
#!/usr/bin/env python3
"""
List running processes: pid, name, cpu%.
Use case: find runaway processes during incidents.
"""
import psutil

def main():
    print(f"{'PID':>6}  {'CPU%':>6}  NAME")
    for p in psutil.process_iter(['pid','name','cpu_percent']):
        info = p.info
        print(f"{info['pid']:>6}  {info.get('cpu_percent',0):>6}  {info.get('name','')}")

if __name__ == "__main__":
    main()
