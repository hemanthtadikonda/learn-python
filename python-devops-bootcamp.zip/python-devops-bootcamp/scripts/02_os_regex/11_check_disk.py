
#!/usr/bin/env python3
"""
Check disk usage and alert if above threshold.
Use case: prevent disk-full incidents.
"""
import argparse, psutil, sys

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--mount", default="/")
    p.add_argument("--threshold", type=int, default=80, help="percent used")
    a = p.parse_args()
    usage = psutil.disk_usage(a.mount)
    used = usage.percent
    print(f"Disk {a.mount}: {used}% used")
    if used >= a.threshold:
        print("ALERT: Threshold exceeded!", file=sys.stderr); sys.exit(1)

if __name__ == "__main__":
    main()
