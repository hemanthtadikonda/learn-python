
#!/usr/bin/env python3
"""
Simple CPU/Memory monitor (one-shot).
Use case: lightweight health probe for nodes.
"""
import psutil, json

stats = {
    "cpu_percent": psutil.cpu_percent(interval=1.0),
    "mem_percent": psutil.virtual_memory().percent,
    "swap_percent": psutil.swap_memory().percent,
}
print(json.dumps(stats, indent=2))
