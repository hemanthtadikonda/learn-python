# Python DevOps Bootcamp – 60 Practical Scripts

A hands-on, production-style Python scripting curriculum for DevOps & SRE engineers.  
Use these scripts to practice, automate real ops tasks, and showcase in interviews.

## Repo Layout
```
python-devops-bootcamp/
├─ README.md
├─ requirements.txt
├─ LICENSE (MIT)
└─ scripts/
   ├─ 01_basics/          # 1–10
   ├─ 02_os_regex/        # 11–20
   ├─ 03_api_json_yaml/   # 21–30
   ├─ 04_advanced/        # 31–40
   └─ 05_devops/          # 41–60
```

> Each script is a single, runnable file with CLI args (`-h` for help), logging, and clean structure.

## How to Use
```bash
# (Recommended) Create a virtual environment
python3 -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate

# Install dependencies (only what you need for the scripts you run)
pip install -r requirements.txt

# Run any script (examples)
python scripts/01_basics/01_hello_devops.py
python scripts/02_os_regex/11_check_disk.py --threshold 80
python scripts/03_api_json_yaml/21_fetch_public_api.py --city Hyderabad
```

## Learning Plan
- Week 1: Basics (1–10) – file handling, loops, functions
- Week 2: OS/Regex (11–20) – subprocess, psutil, sockets, regex
- Week 3: APIs/JSON/YAML (21–30) – requests, PyYAML, retries
- Week 4: Advanced (31–40) – decorators, threading, asyncio, testing, packaging
- Week 5–6: DevOps (41–60) – SSH, AWS, Docker, K8s, CI/CD, security, monitoring

## Scripts Index (1–60)
See the roadmap in the conversation or open each folder for details.
Pull requests for improvements are welcome!
